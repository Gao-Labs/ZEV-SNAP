import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp

class BEVAnalysis:
    def __init__(self):
        # Model parameters
        self.params = {
            'r1': 0.05168618830477891,
            'K1': 18.249120552226596,
            'alpha1': 0.000439984626820028,
            'alpha2': 18.203716832193724,
            'alpha3': 7.637298746066146,
            'r2': 0.618,
            'beta1': 0.008630481176530695,
            'gamma1': 0.28377782685370234,
            'r3': 0.4977205757342527,
            'beta2': 3.167966073633332e-05,
            'gamma2': 0.6673314902149782,
            'r4': 0.5887095281051045,
            'beta3': 2.1983443421482386e-05,
            'gamma3': 0.4758914870452181,
            'phi1': 12.605596145217056,
            'phi2': 0.288810618291974,
            'phi3': 0.09182794376396546,
            'phi4': 0.04697673651638769, 
            'eta': 13.279476743655328,
            'psi1': 0.9498918325322229,
            'psi2': 0.9967261435403867,
            'psi3': 1.6041671050490263,
            'psi4': 0.01759812636076682,
            'delta': 0.9384557200652857,
            'epsilon': 0.006353691336850258,
            'zeta': 0.08195297046883737,
            'k_C': 1.9842416005558203,
            'k_V': 0.0078967652396,
            'k_A': 0.00022996575708375,
            'k_D': 0.0595049804633432,
            'lambda_C': 12.503328097970362,
            'lambda_V': 0.06711238756229986,
            'lambda_A': 0.027100037342708213,
            'lambda_D': 0.035885574797121296,
            'lambda_O': 2.1759119997366057,
            'kappa': 0.378394290697231,
            'lambda_S': 0.009714472603102214,
            'omega': 0.021594560008974,
            'tau': 0.03251495646929492,
            'cvrp_end_year': 2023,
            'start_year': 2010  # Added for reference in the system function
        }
        self.load_data()

    def load_data(self):
        """Load and normalize data"""
        try:
            # Try to load from ZEVdata.xlsx
            data = pd.read_excel('C:/Users/as3889/Desktop/ZEVdata.xlsx')
        except Exception as e:
            print(f"Error loading ZEVdata.xlsx: {e}")
            # Create sample data for demonstration purposes
            years = np.arange(2010, 2024)
            V_ICE = np.array([240e6, 242e6, 244e6, 246e6, 248e6, 250e6, 251e6, 252e6, 253e6, 254e6, 255e6, 256e6, 257e6, 258e6])
            V_BEV = np.array([0.1e6, 0.2e6, 0.4e6, 0.6e6, 0.8e6, 1.0e6, 1.5e6, 2.0e6, 2.5e6, 3.0e6, 3.5e6, 4.0e6, 4.5e6, 5.0e6])
            M = np.array([800e9, 810e9, 820e9, 830e9, 840e9, 850e9, 860e9, 870e9, 880e9, 890e9, 900e9, 910e9, 920e9, 930e9])
            C = np.array([10e6, 12e6, 14e6, 16e6, 18e6, 20e6, 22e6, 24e6, 26e6, 28e6, 30e6, 32e6, 34e6, 36e6])
            S = np.array([3e3, 5e3, 8e3, 12e3, 16e3, 20e3, 25e3, 30e3, 35e3, 40e3, 45e3, 50e3, 55e3, 60e3])
            
            data = pd.DataFrame({
                'Year': years,
                'V': V_ICE,
                'BEV': V_BEV,
                'M': M,
                'C': C,
                'S': S
            })
            print("Using sample data instead")
            
        self.years = data['Year'].values
        self.V_ICE_data = data['V'].values
        self.V_BEV_data = data['BEV'].values
        self.M_data = data['M'].values
        self.C_data = data['C'].values
        self.S_data = data['S'].values

        # Normalize data
        self.V_ICE_mean = np.mean(self.V_ICE_data)
        self.V_BEV_mean = np.mean(self.V_BEV_data)
        self.M_mean = np.mean(self.M_data)
        self.C_mean = np.mean(self.C_data)
        self.S_mean = np.mean(self.S_data)

        self.V_ICE_norm = self.V_ICE_data / self.V_ICE_mean
        self.V_BEV_norm = self.V_BEV_data / self.V_BEV_mean
        self.M_norm = self.M_data / self.M_mean
        self.C_norm = self.C_data / self.C_mean
        self.S_norm = self.S_data / self.S_mean

    def system(self, t, X, params):
        """System of differential equations for BEV adoption"""
        V, B, M, C, S = X
        
        # Calculate current year from time t
        current_year = params['start_year'] + t
        
        total_vehicles = V + B
        ev_fraction = B / total_vehicles if total_vehicles > 0 else 0

        # Determine which incentives are active based on current year
        active_incentives = 0
        
        # Only include CVRP (k_C) if the current year is at or before the CVRP end year
        if current_year <= params['cvrp_end_year']:
            active_incentives += params['k_C']
        
        # Other incentives continue through the entire simulation
        active_incentives += params['k_V'] + params['k_D'] + params['k_A']

        dV_dt = params['r1'] * V * (1 - total_vehicles/params['K1']) * \
                (1 - params['omega'] * ev_fraction) - params['tau'] * V * ev_fraction - \
                params['epsilon'] * V
        dB_dt = params['r2'] * B + params['beta1'] * active_incentives + \
                params['alpha1'] * params['tau'] * V * ev_fraction - params['gamma1'] * B
        dM_dt = params['phi1'] * V + params['phi2'] * B - params['eta'] * M
        dC_dt = (params['psi1'] * V + params['psi2'] * B) * M / total_vehicles - \
                params['delta'] * C + params['zeta'] * (V / total_vehicles) ** 2
        dS_dt = params['kappa'] * B / total_vehicles - params['lambda_S'] * S

        return [dV_dt, dB_dt, dM_dt, dC_dt, dS_dt]

    def calculate_historical_rmse(self):
        """Calculate RMSE using all historical data"""
        # Initial conditions from 2010
        X0_2010 = [
            self.V_ICE_data[0]/self.V_ICE_mean,
            self.V_BEV_data[0]/self.V_BEV_mean,
            self.M_data[0]/self.M_mean,
            self.C_data[0]/self.C_mean,
            self.S_data[0]/self.S_mean
        ]
        
        # Solve for entire historical period
        years_span = len(self.years)
        t_eval = np.linspace(0, years_span-1, years_span)
        solution = solve_ivp(
            self.system,
            (0, years_span-1),
            X0_2010,
            args=(self.params,),
            t_eval=t_eval,
            method='RK45'
        )
        
        # Get predictions and calculate metrics
        predicted_bev = solution.y[1] * self.V_BEV_mean
        rmse = np.sqrt(np.mean((self.V_BEV_data - predicted_bev)**2))
        rmse_percentage = rmse / np.mean(self.V_BEV_data)
        mae = np.mean(np.abs(self.V_BEV_data - predicted_bev))
        mape = np.mean(np.abs((self.V_BEV_data - predicted_bev) / self.V_BEV_data)) * 100
        
        return {
            'rmse_absolute': rmse,
            'rmse_percentage': rmse_percentage,
            'mae': mae,
            'mape': mape,
            'years': self.years,
            'actual': self.V_BEV_data,
            'predicted': predicted_bev
        }

    def run_scenario(self, growth_ratio, incentive_ratio, total_budget=5e9, years=4):
        """Run scenario without Monte Carlo simulation using continuous simulation from 2010"""
        scenario_params = self.params.copy()
        
        growth_scaling = 1 + (growth_ratio * total_budget/years/1e9) * 0.10
        incentive_scaling = 1 + (incentive_ratio * total_budget/years/1e9) * 0.13
        
        # Modify parameters for scenario
        scenario_params['r2'] *= growth_scaling
        scenario_params['k_C'] *= incentive_scaling
        scenario_params['k_V'] *= incentive_scaling
        scenario_params['k_A'] *= incentive_scaling
        scenario_params['k_D'] *= incentive_scaling
        scenario_params['beta1'] *= incentive_scaling
        
        # Initial conditions from 2010
        X0_2010 = [
            self.V_ICE_data[0]/self.V_ICE_mean,
            self.V_BEV_data[0]/self.V_BEV_mean,
            self.M_data[0]/self.M_mean,
            self.C_data[0]/self.C_mean,
            self.S_data[0]/self.S_mean
        ]
        
        # Single continuous simulation from 2010 to 2027 (17 years)
        total_years = 17  # 2010 to 2027
        t_eval = np.linspace(0, total_years, total_years*12+1)
        
        solution = solve_ivp(
            self.system,
            (0, total_years),
            X0_2010,
            args=(scenario_params,),
            t_eval=t_eval,
            method='RK45'
        )
          
        # Process results
        years = np.array([2010 + t for t in solution.t])
        bev_values = solution.y[1] * self.V_BEV_mean
        ice_values = solution.y[0] * self.V_ICE_mean
        ev_fraction = bev_values / (bev_values + ice_values)
        
        # Split into historical and future periods
        historical_mask = years <= 2024
        future_mask = years >= 2024
        
        years_historical = years[historical_mask]
        years_future = years[future_mask]
        bev_historical = bev_values[historical_mask]
        bev_future = bev_values[future_mask]
        ice_historical = ice_values[historical_mask]
        ice_future = ice_values[future_mask]
        ev_fraction_historical = ev_fraction[historical_mask]
        ev_fraction_future = ev_fraction[future_mask]
        
        return {
            'historical_years': years_historical,
            'historical_bev': bev_historical,
            'historical_ice': ice_historical,
            'historical_ev_fraction': ev_fraction_historical,
            'future_years': years_future,
            'future_bev': bev_future,
            'future_ice': ice_future,
            'future_ev_fraction': ev_fraction_future,
            'scenario_params': {
                'growth_ratio': growth_ratio,
                'incentive_ratio': incentive_ratio,
                'growth_scaling': growth_scaling,
                'incentive_scaling': incentive_scaling,
                'total_budget': total_budget,
                'years': years,
                'r2_modified': scenario_params['r2'],
                'k_C_modified': scenario_params['k_C'],
                'k_V_modified': scenario_params['k_V'],
                'k_A_modified': scenario_params['k_A'],
                'k_D_modified': scenario_params['k_D'],
                'beta1_modified': scenario_params['beta1']
            }
        }

    def run_scenario_from_2023(self, growth_ratio, incentive_ratio, total_budget=5e9, years=4):
        """Run scenario using 2023 data as initial condition for projections"""
        # First, simulate up to 2023 to get the state at that point
        base_params = self.params.copy()
        
        # Initial conditions from 2010
        X0_2010 = [
            self.V_ICE_data[0]/self.V_ICE_mean,
            self.V_BEV_data[0]/self.V_BEV_mean,
            self.M_data[0]/self.M_mean,
            self.C_data[0]/self.C_mean,
            self.S_data[0]/self.S_mean
        ]
        
        # Simulate from 2010 to 2023 (13 years)
        historical_years = 13  # 2010 to 2023
        t_eval_hist = np.linspace(0, historical_years, historical_years*12+1)
        
        historical_solution = solve_ivp(
            self.system,
            (0, historical_years),
            X0_2010,
            args=(base_params,),
            t_eval=t_eval_hist,
            method='RK45'
        )
        
        # Get the final state from 2023 to use as initial state for projections
        X0_2023 = [historical_solution.y[i][-1] for i in range(5)]
        
        # Create parameters for future projection
        scenario_params = self.params.copy()
        
        growth_scaling = 1 + (growth_ratio * total_budget/years/1e9) * 0.30
        incentive_scaling = 1 + (incentive_ratio * total_budget/years/1e9) * 0.32
        
        # Modify parameters for scenario
        scenario_params['r2'] *= growth_scaling
        scenario_params['k_C'] *= incentive_scaling
        scenario_params['k_V'] *= incentive_scaling
        scenario_params['k_A'] *= incentive_scaling
        scenario_params['k_D'] *= incentive_scaling
        scenario_params['beta1'] *= incentive_scaling
        
        # Set the start year to 2023 for the projection period
        scenario_params['start_year'] = 2023
        
        # Future simulation (2023 to 2027) - 4 years
        future_years = 4  # 2023 to 2027
        t_eval_future = np.linspace(0, future_years, future_years*12+1)
        
        future_solution = solve_ivp(
            self.system,
            (0, future_years),
            X0_2023,
            args=(scenario_params,),
            t_eval=t_eval_future,
            method='RK45'
        )
        
        # Process results
        historical_years_array = np.array([2010 + t for t in historical_solution.t])
        future_years_array = np.array([2023 + t for t in future_solution.t])
        
        historical_bev = historical_solution.y[1] * self.V_BEV_mean
        future_bev = future_solution.y[1] * self.V_BEV_mean
        
        historical_ice = historical_solution.y[0] * self.V_ICE_mean
        future_ice = future_solution.y[0] * self.V_ICE_mean
        
        historical_ev_fraction = historical_bev / (historical_bev + historical_ice)
        future_ev_fraction = future_bev / (future_bev + future_ice)
        
        return {
            'historical_years': historical_years_array,
            'historical_bev': historical_bev,
            'historical_ice': historical_ice,
            'historical_ev_fraction': historical_ev_fraction,
            'future_years': future_years_array,
            'future_bev': future_bev,
            'future_ice': future_ice,
            'future_ev_fraction': future_ev_fraction,
            'scenario_params': {
                'growth_ratio': growth_ratio,
                'incentive_ratio': incentive_ratio,
                'growth_scaling': growth_scaling,
                'incentive_scaling': incentive_scaling,
                'total_budget': total_budget,
                'years': years,
                'r2_modified': scenario_params['r2'],
                'k_C_modified': scenario_params['k_C'],
                'k_V_modified': scenario_params['k_V'],
                'k_A_modified': scenario_params['k_A'],
                'k_D_modified': scenario_params['k_D'],
                'beta1_modified': scenario_params['beta1']
            }
        }

    def plot_historical_fit(self, rmse_results):
        """Plot historical model fit"""
        plt.figure(figsize=(12, 6))
        
        # Plot actual values
        plt.plot(rmse_results['years'], 
                rmse_results['actual']/1e6, 
                'bo-', 
                label='Actual', 
                linewidth=2)
        
        # Plot predicted values
        plt.plot(rmse_results['years'], 
                rmse_results['predicted']/1e6, 
                'r--', 
                label='Predicted', 
                linewidth=2)
        
        plt.title('Model Validation (2010-2023)', fontsize=14, pad=20)
        plt.xlabel('Year', fontsize=12)
        plt.ylabel('BEV Vehicles (Millions)', fontsize=12)
        plt.grid(True, linestyle='--', alpha=0.7)
        plt.legend(fontsize=12)
        
        # Rotate x-axis labels for better readability
        plt.xticks(rotation=45)
        
        # Adjust layout to prevent label cutoff
        plt.tight_layout()
        plt.show()

    def plot_scenarios(self, scenario_results):
        """Plot scenario comparison"""
        plt.figure(figsize=(14, 8))
        
        colors = {'Growth Focus': 'blue', 'Incentive Focus': 'green'}
        
        for name, results in scenario_results.items():
            color = colors.get(name, 'gray')
            
            # Plot historical period
            plt.plot(results['historical_years'],
                    results['historical_bev']/1e6,
                    linestyle=':',
                    color=color,
                    label=f"{name} (Historical)",
                    alpha=0.7)
            
            # Plot future predictions
            plt.plot(results['future_years'],
                    results['future_bev']/1e6,
                    linestyle='-',
                    color=color,
                    label=f"{name} (Projected)",
                    linewidth=2)
        
        # Add vertical line for projection start
        plt.axvline(x=2024, color='gray', linestyle='--', alpha=0.5)
        plt.text(2024.1, plt.ylim()[1]*0.95, 'Projection Start', 
                rotation=90, verticalalignment='top')
        
        plt.title('BEV Adoption Scenarios',
                 fontsize=16, pad=20)
        plt.xlabel('Year', fontsize=14)
        plt.ylabel('BEV Vehicles (Millions)', fontsize=14)
        plt.grid(True, linestyle='--', alpha=0.7)
        plt.legend(fontsize=12, bbox_to_anchor=(1.05, 1), loc='upper left')
        
        # Rotate x-axis labels for better readability
        plt.xticks(rotation=45)
        
        # Adjust layout to prevent label cutoff
        plt.tight_layout()
        plt.show()
        
        # Also plot EV market share
        plt.figure(figsize=(14, 8))
        
        for name, results in scenario_results.items():
            color = colors.get(name, 'gray')
            
            # Plot historical period
            plt.plot(results['historical_years'],
                    results['historical_ev_fraction']*100,
                    linestyle=':',
                    color=color,
                    label=f"{name} (Historical)",
                    alpha=0.7)
            
            # Plot future predictions
            plt.plot(results['future_years'],
                    results['future_ev_fraction']*100,
                    linestyle='-',
                    color=color,
                    label=f"{name} (Projected)",
                    linewidth=2)
        
        # Add vertical line for projection start
        plt.axvline(x=2024, color='gray', linestyle='--', alpha=0.5)
        plt.text(2024.1, plt.ylim()[1]*0.95, 'Projection Start', 
                rotation=90, verticalalignment='top')
        
        plt.title('BEV Market Share Scenarios',
                 fontsize=16, pad=20)
        plt.xlabel('Year', fontsize=14)
        plt.ylabel('BEV Market Share (%)', fontsize=14)
        plt.grid(True, linestyle='--', alpha=0.7)
        plt.legend(fontsize=12, bbox_to_anchor=(1.05, 1), loc='upper left')
        
        # Rotate x-axis labels for better readability
        plt.xticks(rotation=45)
        
        # Adjust layout to prevent label cutoff
        plt.tight_layout()
        plt.show()

def main():
    # Initialize analysis
    analysis = BEVAnalysis()
    
    # Calculate historical RMSE
    rmse_results = analysis.calculate_historical_rmse()
    print("\nHistorical Model Performance:")
    print(f"RMSE (%): {rmse_results['rmse_percentage']*100:.2f}%")
    print(f"MAPE: {rmse_results['mape']:.2f}%")
    print(f"MAE: {rmse_results['mae']/1e6:.2f}M vehicles")

    # Plot historical fit
    print("\nPlotting historical model fit...")
    analysis.plot_historical_fit(rmse_results)

    # Define scenarios
    scenarios = {
        "Growth Focus": (0.7, 0.3),
        "Incentive Focus": (0.3, 0.7)
    }

    print("\n===== Method 1: Continuous simulation from 2010 =====")
    # Run scenarios with continuous simulation from 2010
    print("\nRunning scenarios (continuous from 2010)...")
    scenario_results_continuous = {}
    for name, (growth_ratio, incentive_ratio) in scenarios.items():
        print(f"\nProcessing {name} scenario...")
        results = analysis.run_scenario(
            growth_ratio,
            incentive_ratio,
            total_budget=5e9,
            years=4
        )
        scenario_results_continuous[name] = results

    # Plot scenarios
    print("\nPlotting scenario comparisons (continuous from 2010)...")
    analysis.plot_scenarios(scenario_results_continuous)

    # Print final results
    print("\nFinal Results Summary (continuous from 2010):")
    
    # Create a table of results
    result_data_continuous = []
    for name in scenario_results_continuous:
        result = scenario_results_continuous[name]
        final_bev = result['future_bev'][-1]/1e6
        final_ev_fraction = result['future_ev_fraction'][-1]*100
        growth_ratio = result['scenario_params']['growth_ratio']
        incentive_ratio = result['scenario_params']['incentive_ratio']
        
        result_data_continuous.append({
            'Scenario': name,
            'Growth Ratio': growth_ratio,
            'Incentive Ratio': incentive_ratio,
            'BEV Fleet (M)': final_bev, 
            'Market Share (%)': final_ev_fraction
        })
    
    # Print as a formatted table
    result_df_continuous = pd.DataFrame(result_data_continuous)
    pd.set_option('display.float_format', '{:.2f}'.format)
    print(result_df_continuous)
    
    print("\n===== Method 2: Separate simulation starting from 2023 =====")
    # Run scenarios with 2023 as initial condition for projections
    print("\nRunning scenarios (starting from 2023)...")
    scenario_results_2023 = {}
    for name, (growth_ratio, incentive_ratio) in scenarios.items():
        print(f"\nProcessing {name} scenario...")
        results = analysis.run_scenario_from_2023(
            growth_ratio,
            incentive_ratio,
            total_budget=5e9,
            years=4
        )
        scenario_results_2023[name] = results

    # Plot scenarios
    print("\nPlotting scenario comparisons (starting from 2023)...")
    analysis.plot_scenarios(scenario_results_2023)

    # Print final results
    print("\nFinal Results Summary (starting from 2023):")
    
    # Create a table of results
    result_data_2023 = []
    for name in scenario_results_2023:
        result = scenario_results_2023[name]
        final_bev = result['future_bev'][-1]/1e6
        final_ev_fraction = result['future_ev_fraction'][-1]*100
        growth_ratio = result['scenario_params']['growth_ratio']
        incentive_ratio = result['scenario_params']['incentive_ratio']
        
        result_data_2023.append({
            'Scenario': name,
            'Growth Ratio': growth_ratio,
            'Incentive Ratio': incentive_ratio,
            'BEV Fleet (M)': final_bev, 
            'Market Share (%)': final_ev_fraction
        })
    
    # Print as a formatted table
    result_df_2023 = pd.DataFrame(result_data_2023)
    pd.set_option('display.float_format', '{:.2f}'.format)
    print(result_df_2023)
    
    # Print comparison of the two methods
    print("\n===== Comparison of Methods =====")
    comparison_data = []
    for name in scenarios:
        continuous_result = result_data_continuous[list(scenarios.keys()).index(name)]
        from_2023_result = result_data_2023[list(scenarios.keys()).index(name)]
        
        comparison_data.append({
            'Scenario': name,
            'Continuous BEV (M)': continuous_result['BEV Fleet (M)'],
            '2023 Start BEV (M)': from_2023_result['BEV Fleet (M)'],
            'Difference (M)': continuous_result['BEV Fleet (M)'] - from_2023_result['BEV Fleet (M)'],
            'Difference (%)': (continuous_result['BEV Fleet (M)'] - from_2023_result['BEV Fleet (M)']) / from_2023_result['BEV Fleet (M)'] * 100
        })
    
    comparison_df = pd.DataFrame(comparison_data)
    print(comparison_df)
    
    # Print detailed scenario parameter changes
    print("\nParameter Modifications by Scenario:")
    for name in scenario_results_continuous:
        result = scenario_results_continuous[name]
        params = result['scenario_params']
        
        print(f"\n{name}:")
        print(f"  Growth scaling factor: {params['growth_scaling']:.4f}")
        print(f"  Incentive scaling factor: {params['incentive_scaling']:.4f}")
        print(f"  r2 (BEV growth rate): {params['r2_modified']:.4f} (base: {analysis.params['r2']:.4f})")
        print(f"  k_C (CVRP - ending in 2023): {params['k_C_modified']:.4f} (base: {analysis.params['k_C']:.4f})")
        print(f"  k_V (CVAP): {params['k_V_modified']:.4f} (base: {analysis.params['k_V']:.4f})")
        print(f"  k_A (CC4A): {params['k_A_modified']:.4f} (base: {analysis.params['k_A']:.4f})")
        print(f"  k_D (DCAP): {params['k_D_modified']:.4f} (base: {analysis.params['k_D']:.4f})")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"Error in analysis: {str(e)}")
        import traceback
        traceback.print_exc()
        print("Please ensure all data files are available and properly formatted.")