import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
# Remove seaborn import

# Load data
data = pd.read_excel('C:/Users/as3889/Desktop/ZEVdata.xlsx')
years = data['Year'].values
V_ICE_data = data['V'].values
V_BEV_data = data['BEV'].values
V_PHEV_data = data['PHEV'].values
V_FCEV_data = data['FCEV'].values
M_data = data['M'].values
C_data = data['C'].values
S_data = data['S'].values

# Normalize data
V_ICE_mean, V_BEV_mean = np.mean(V_ICE_data), np.mean(V_BEV_data)
M_mean, C_mean, S_mean = np.mean(M_data), np.mean(C_data), np.mean(S_data)

V_ICE_norm = V_ICE_data / V_ICE_mean
V_BEV_norm = V_BEV_data / V_BEV_mean
M_norm = M_data / M_mean
C_norm = C_data / C_mean
S_norm = S_data / S_mean

# Base year and initial conditions
base_year = 2010
X0 = [V_ICE_norm[0], V_BEV_norm[0], M_norm[0], C_norm[0], S_norm[0]]

# Model parameters
params = {
    'r1': 0.04600309537728457,
    'K1': 19.988853430783674,
    'alpha1': 2.1990994330017567e-20,
    'r2': 0.4272847858514477,
    'beta1': 0.0009,
    'gamma1': 0.006195813413796029,
    'phi1': 2.420439212993679,
    'phi2': 0.03290625472523172,
    'eta': 2.472995227365455,
    'psi1': 0.877999000323586,
    'psi2': 0.8825501230310412,
    'delta': 0.8114852069566516,
    'epsilon': 1.6113341002621433e-34,
    'zeta': 8.756752159763104e-12,
    'k_C': 9.466080903837223,
    'k_V': 1.1743857370252369,
    'k_A': 0.9252378762028231,
    'k_D': 1.282707168138512,
    'lambda_C': 0.1699545021325927,
    'lambda_V': 0.16153300196227824,
    'lambda_A': 0.16300789498583168,
    'lambda_D': 0.16186856013035358,
    'kappa': 0.3673510495799293,
    'lambda_S': 0.004719196117653555,
    'omega': 0.0773179311036966,
    'tau': 0.04,
    'cvrp_end_year': 2023
}

def incentive_time_effect(t, start_year, end_year, incentive_amount, decay_rate):
    if start_year <= t <= end_year:
        return incentive_amount * np.exp(-decay_rate * (t - start_year))
    return 0

def system(t, X, params):
    V, B, M, C, S = X
    
    # Unpack parameters
    r1, K1, alpha1, r2, beta1, gamma1, phi1, phi2, eta, psi1, psi2, delta, epsilon, \
    zeta, k_C, k_V, k_A, k_D, lambda_C, lambda_V, lambda_A, lambda_D, kappa, \
    lambda_S, omega, tau, cvrp_end_year = params.values()

    # Calculate incentive effects
    total_incentive = calculate_total_incentives(t + base_year, params)
    total_vehicles = V + B
    ev_fraction = B / total_vehicles if total_vehicles > 0 else 0

    # System equations
    dV_dt = r1 * V * (1 - total_vehicles/K1) * (1 - omega * ev_fraction) - tau * V * ev_fraction - epsilon * V
    dB_dt = r2 * B + beta1 * total_incentive + alpha1 * tau * V * ev_fraction - gamma1 * B
    dM_dt = phi1 * V + phi2 * B - eta * M
    dC_dt = (psi1 * V + psi2 * B) * M / total_vehicles - delta * C + zeta * (V / total_vehicles) ** 2
    dS_dt = kappa * B / total_vehicles - lambda_S * S

    return [dV_dt, dB_dt, dM_dt, dC_dt, dS_dt]

def calculate_total_incentives(t, params):
    cvrp_effect = incentive_time_effect(t, 2010, params['cvrp_end_year'], 
                                      params['k_C'], params['lambda_C'])
    cvap_effect = incentive_time_effect(t, 2018, 2030, 
                                      params['k_V'], params['lambda_V'])
    cc4a_effect = incentive_time_effect(t, 2015, 2030, 
                                      params['k_A'], params['lambda_A'])
    dcap_effect = incentive_time_effect(t, 2016, 2030, 
                                      params['k_D'], params['lambda_D'])
    
    return cvrp_effect + cvap_effect + cc4a_effect + dcap_effect

def project_ev_adoption(projection_year, params):
    t_span = (0, projection_year - base_year)
    t_eval = np.arange(0, projection_year - base_year + 1, 1)

    solution = solve_ivp(system, t_span, X0, args=(params,), t_eval=t_eval, method='RK45')

    V_ICE_proj = solution.y[0] * V_ICE_mean
    V_BEV_proj = solution.y[1] * V_BEV_mean
    projection_years = np.arange(base_year, projection_year + 1)

    return projection_years, V_ICE_proj, V_BEV_proj

def plot_growth_rate_analysis(projection_year=2027):
    # Create scenarios
    variations = {
        'Low (-10%)': 0.9,
        'Base': 1.0,
        'High (+10%)': 1.1
    }
    
    scenarios = {}
    results = []
    base_value = params['r2']
    
    for name, factor in variations.items():
        params_var = params.copy()
        params_var['r2'] = base_value * factor
        years, _, bev = project_ev_adoption(projection_year, params_var)
        scenarios[name] = {'years': years, 'BEV': bev}
        
        # Store results for final year
        results.append({
            'Scenario': name,
            'BEV_Count': bev[-1]
        })
    
    # Calculate metrics
    final_values = [d['BEV'][-1] for d in scenarios.values()]
    mean_val = np.mean(final_values)
    cv = (np.std(final_values) / mean_val) * 100
    
    # Create plots with matplotlib style
    plt.style.use('default')
    
    # Set general font size and style
    plt.rcParams.update({
        'font.size': 12,
        'axes.labelsize': 12,
        'axes.titlesize': 14,
        'xtick.labelsize': 10,
        'ytick.labelsize': 10
    })
    
    # Figure 1: Trajectories
    fig1, ax1 = plt.subplots(figsize=(12, 6))
    colors = ['blue', 'green', 'red']
    
    for (name, data), color in zip(scenarios.items(), colors):
        ax1.plot(data['years'], data['BEV'], 
                label=name, color=color, linewidth=2, marker='o')
    
    ax1.set_title('BEV Adoption Under Different Growth Rate Scenarios', fontsize=14)
    ax1.set_xlabel('Year', fontsize=12)
    ax1.set_ylabel('Number of BEVs', fontsize=12)
    ax1.legend()
    # Enhance grid and figure appearance
    ax1.grid(True, linestyle='--', alpha=0.7)
    ax1.spines['top'].set_visible(False)
    ax1.spines['right'].set_visible(False)
    
    # Figure 2: Bar plot for 2027
    fig2, ax2 = plt.subplots(figsize=(10, 6))
    results_df = pd.DataFrame(results)
    
    bars = ax2.bar(results_df['Scenario'], results_df['BEV_Count'])
    ax2.set_title('BEV Adoption by Scenario in 2027', fontsize=14)
    ax2.set_ylabel('Number of BEVs', fontsize=12)
    
    # Add value labels on bars
    for bar in bars:
        height = bar.get_height()
        ax2.text(bar.get_x() + bar.get_width()/2., height,
                f'{height:,.0f}',
                ha='center', va='bottom')
    
    plt.tight_layout()
    
    # Save figures
    fig1.savefig('growth_rate_trajectories.jpg', dpi=300, bbox_inches='tight')
    fig2.savefig('growth_rate_comparison.jpg', dpi=300, bbox_inches='tight')
    plt.show()
    
    # Print metrics
    print(f"\nMean BEV Projection: {mean_val:,.0f}")
    print(f"Coefficient of Variation: {cv:.1f}%")
    
    return scenarios, mean_val, cv

def plot_incentive_analysis(projection_year=2027):
    """Analyze BEV adoption under different incentive scenarios"""
    
    # Define incentive parameter variations
    variations = {
        'Low (-10%)': 0.9,
        'Base': 1.0,
        'High (+10%)': 1.1
    }
    
    scenarios = {}
    results = []
    # Base values for incentive parameters
    base_values = {
        'k_C': params['k_C'],  # CVRP coefficient
        'k_V': params['k_V'],  # CVAP coefficient
        'k_A': params['k_A'],  # CC4A coefficient
        'k_D': params['k_D']   # DCAP coefficient
    }
    
    # Create scenarios varying all incentive parameters together
    for name, factor in variations.items():
        params_var = params.copy()
        # Modify all incentive parameters
        for key in ['k_C', 'k_V', 'k_A', 'k_D']:
            params_var[key] = base_values[key] * factor
            
        years, _, bev = project_ev_adoption(projection_year, params_var)
        scenarios[name] = {'years': years, 'BEV': bev}
        
        # Store results for final year
        results.append({
            'Scenario': name,
            'BEV_Count': bev[-1]
        })
    
    # Calculate metrics
    final_values = [d['BEV'][-1] for d in scenarios.values()]
    mean_val = np.mean(final_values)
    cv = (np.std(final_values) / mean_val) * 100
    
    # Create plots
    plt.style.use('default')
    plt.rcParams.update({
        'font.size': 12,
        'axes.labelsize': 12,
        'axes.titlesize': 14,
        'xtick.labelsize': 10,
        'ytick.labelsize': 10
    })
    
    # Figure 1: Trajectories
    fig1, ax1 = plt.subplots(figsize=(12, 6))
    colors = ['blue', 'green', 'red']
    
    for (name, data), color in zip(scenarios.items(), colors):
        ax1.plot(data['years'], data['BEV'], 
                label=name, color=color, linewidth=2, marker='o')
    
    ax1.set_title('BEV Adoption Under Different Incentive Scenarios', fontsize=14)
    ax1.set_xlabel('Year', fontsize=12)
    ax1.set_ylabel('Number of BEVs', fontsize=12)
    ax1.legend()
    ax1.grid(True, linestyle='--', alpha=0.7)
    ax1.spines['top'].set_visible(False)
    ax1.spines['right'].set_visible(False)
    
    # Figure 2: Bar plot for 2027
    fig2, ax2 = plt.subplots(figsize=(10, 6))
    results_df = pd.DataFrame(results)
    
    bars = ax2.bar(results_df['Scenario'], results_df['BEV_Count'])
    ax2.set_title('BEV Adoption by Incentive Scenario in 2027', fontsize=14)
    ax2.set_ylabel('Number of BEVs', fontsize=12)
    ax2.spines['top'].set_visible(False)
    ax2.spines['right'].set_visible(False)
    ax2.grid(True, axis='y', linestyle='--', alpha=0.7)
    
    # Add value labels on bars
    for bar in bars:
        height = bar.get_height()
        ax2.text(bar.get_x() + bar.get_width()/2., height,
                f'{height:,.0f}',
                ha='center', va='bottom')
    
    plt.tight_layout()
    
    # Save figures
    fig1.savefig('incentive_trajectories.jpg', dpi=300, bbox_inches='tight')
    fig2.savefig('incentive_comparison.jpg', dpi=300, bbox_inches='tight')
    plt.show()
    
    # Print metrics
    print(f"\nIncentive Analysis Results:")
    print(f"Mean BEV Projection: {mean_val:,.0f}")
    print(f"Coefficient of Variation: {cv:.1f}%")
    
    # Create detailed results table
    results_table = pd.DataFrame({
        'Scenario': list(variations.keys()),
        'BEV Adoption': [scenarios[name]['BEV'][-1] for name in variations.keys()],
        'Change from Base (%)': [
            ((scenarios[name]['BEV'][-1] / scenarios['Base']['BEV'][-1]) - 1) * 100 
            for name in variations.keys()
        ]
    })
    
    print("\nDetailed Results:")
    print(results_table.to_string(index=False))
    
    return scenarios, mean_val, cv

if __name__ == "__main__":
    # Run both analyses
    print("Growth Rate Analysis:")
    growth_scenarios, growth_mean, growth_cv = plot_growth_rate_analysis()
    
    print("\nIncentive Analysis:")
    incentive_scenarios, incentive_mean, incentive_cv = plot_incentive_analysis()