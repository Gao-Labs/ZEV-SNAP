import numpy as np
from scipy.integrate import odeint
from scipy.optimize import least_squares
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
# Load your data from Excel file
data = pd.read_excel('C:/Users/as3889/Desktop/ZEVdata.xlsx')
years = data['Year'].values
V_data = data['V'].values
B_data = data['BEV'].values
P_data = data['PHEV'].values
F_data = data['FCEV'].values
M_data = data['M'].values
C_data = data['C'].values
S_data = data['S'].values

# Normalize the data using mean values
V_mean, B_mean, P_mean, F_mean = np.mean(V_data), np.mean(B_data), np.mean(P_data), np.mean(F_data)
M_mean, C_mean, S_mean = np.mean(M_data), np.mean(C_data), np.mean(S_data)

V_norm = V_data / V_mean
B_norm = B_data / B_mean
P_norm = P_data / P_mean
F_norm = F_data / F_mean
M_norm = M_data / M_mean
C_norm = C_data / C_mean
S_norm = S_data / S_mean

# Base year for time calculation
base_year = 2010

# Incentive calculations
total_incentives = 1511901636 + 25180906 + 121114580 + 2685500
total_vehicles = (426921 + 152330 + 14305) + (3749 + 1121 + 68) + (3597 + 9648 + 144) + (221 + 279 + 7)
mean_incentive = total_incentives / total_vehicles

cvrp_incentive_norm = (1511901636 / (426921 + 152330 + 14305)) / mean_incentive
cvap_incentive_norm = (25180906 / (3749 + 1121 + 68)) / mean_incentive
cc4a_incentive_norm = (121114580 / (3597 + 9648 + 144)) / mean_incentive
dcap_incentive_norm = (2685500 / (221 + 279 + 7)) / mean_incentive

# System of differential equations
def system(X, t, params):
    V, B, P, F, M, C, S = X
    r1, K1, alpha1, alpha2, alpha3, r2, beta1, gamma1, r3, beta2, gamma2, r4, beta3, gamma3, phi1, phi2, phi3, phi4, eta, psi1, psi2, psi3, psi4, delta, epsilon, zeta, k_C, k_V, k_A, k_D, lambda_C, lambda_V, lambda_A, lambda_D, kappa, lambda_S, omega, tau = params
    
    # Incentive calculations
    cvrp_effect = k_C * cvrp_incentive_norm * np.exp(-lambda_C * (t - (2010 - base_year)))
    cvap_effect = k_V * cvap_incentive_norm * np.exp(-lambda_V * (t - (2018 - base_year)))
    cc4a_effect = k_A * cc4a_incentive_norm * np.exp(-lambda_A * (t - (2015 - base_year)))
    dcap_effect = k_D * dcap_incentive_norm * np.exp(-lambda_D * (t - (2016 - base_year)))
    
    
    total_incentive = cvrp_effect + cvap_effect + cc4a_effect + dcap_effect 
    
    total_vehicles = V + B + P + F
    ev_fraction = (B + P + F) / total_vehicles if total_vehicles > 0 else 0

    # Revised equation for dV/dt
    dV_dt = r1 * V * (1 - total_vehicles/K1) * (1 - omega * ev_fraction) - tau * V * ev_fraction - epsilon * V

    # Modified equations for electric vehicles to account for transitions from conventional vehicles
    dB_dt = r2 * B + beta1 * total_incentive + alpha1 * tau * V * ev_fraction - gamma1 * B
    dP_dt = r3 * P + beta2 * total_incentive + alpha2 * tau * V * ev_fraction - gamma2 * P
    dF_dt = r4 * F + beta3 * total_incentive + alpha3 * tau * V * ev_fraction - gamma3 * F
    
    dM_dt = phi1 * V + phi2 * B + phi3 * P + phi4 * F  - eta * M
    
    total_vehicles = V + B + P + F
    dC_dt = (psi1 * V +psi2 * B + psi3 * P + psi4 * F ) * M / total_vehicles  \
            - delta * C \
            + zeta * (V / total_vehicles) ** 2
    
    dS_dt = kappa * (B + P + F) / (V + B + P + F) - lambda_S * S
    
    return [dV_dt, dB_dt, dP_dt, dF_dt, dM_dt, dC_dt, dS_dt]

# Residual function for optimization
def residual(params):
    t = years - base_year
    X0 = [V_norm[0], B_norm[0], P_norm[0], F_norm[0], M_norm[0], C_norm[0], S_norm[0]]
    solution = odeint(system, X0, t, args=(params,))
    
    V_model, B_model, P_model, F_model, M_model, C_model, S_model = solution.T
    
    residuals = np.concatenate([
        (V_model - V_norm),
        (B_model - B_norm),
        (P_model - P_norm),
        (F_model - F_norm),
        (M_model - M_norm),
        (C_model - C_norm),
        (S_model - S_norm)
    ])
    
    return residuals

# Set initial guess and bounds for parameters
# Single-line format for direct copying:
initial_guess = [
    0.05168618830477891,   # r1
    18.249120552226596,    # K1
    0.000439984626820028,  # alpha1
    18.203716832193724,    # alpha2
    7.637298746066146,     # alpha3
    0.618,                 # r2
    0.008630481176530695,  # beta1
    0.28377782685370234,   # gamma1
    0.4977205757342527,    # r3
    3.167966073633332e-05, # beta2
    0.6673314902149782,    # gamma2
    0.5887095281051045,    # r4
    2.1983443421482386e-05, # beta3
    0.4758914870452181,    # gamma3
    12.605596145217056,    # phi1
    0.288810618291974,     # phi2
    0.09182794376396546,   # phi3
    0.04697673651638769,   # phi4
    13.279476743655328,    # eta
    0.9498918325322229,    # psi1
    0.9967261435403867,    # psi2
    1.6041671050490263,    # psi3
    0.01759812636076682,   # psi4
    0.9384557200652857,    # delta
    0.006353691336850258,  # epsilon
    0.08195297046883737,   # zeta
    1.9842416005558203,    # k_C
    0.0078967652396,       # k_V
    0.00022996575708375,   # k_A
    0.0595049804633432,    # k_D
    12.503328097970362,    # lambda_C
    0.06711238756229986,   # lambda_V
    0.027100037342708213,  # lambda_A
    0.035885574797121296,  # lambda_D
    0.378394290697231,     # kappa
    0.009714472603102214,  # lambda_S
    0.021594560008974,     # omega
    0.03251495646929492    # tau
]


bounds = (
    # Lower bounds
    [0] * len(initial_guess),
    
    # Upper bounds - can be adjusted based on domain knowledge
    [np.inf] * len(initial_guess)
)
# Perform least squares optimization
result = least_squares(residual, initial_guess, bounds=bounds, method='trf', ftol=1e-08, xtol=1e-08, max_nfev=10000)

# Extract optimized parameters
optimized_params = result.x

# Print optimized parameters
param_names = ['r1', 'K1', 'alpha1', 'alpha2', 'alpha3', 'r2', 'beta1', 'gamma1', 'r3', 'beta2', 'gamma2', 'r4', 'beta3', 'gamma3',     'phi1', 'phi2', 'phi3', 'phi4',    'eta', 'psi1', 'psi2', 'psi3', 'psi4', 'delta', 'epsilon', 'zeta', 'k_C', 'k_V', 'k_A', 'k_D', 'k_O', 'lambda_C', 'lambda_V', 'lambda_A', 'lambda_D', 'lambda_O', 'kappa', 'lambda_S', 'omega','tau']
for name, value in zip(param_names, optimized_params):
    print(f"{name}: {value}")

# Solve the system with optimized parameters
t = years - base_year
X0 = [V_norm[0], B_norm[0], P_norm[0], F_norm[0], M_norm[0], C_norm[0], S_norm[0]]
solution = odeint(system, X0, t, args=(optimized_params,))

# Plot normalized results
fig, axs = plt.subplots(4, 2, figsize=(16, 32))
axs = axs.ravel()

variables = [V_norm, B_norm, P_norm, F_norm, M_norm, C_norm, S_norm]
labels = ['Normalized ICE Vehicles', 'Normalized BEVs', 'Normalized PHEVs', 'Normalized FCEVs', 'Normalized VMT', 'Normalized CO2 Emissions', 'Normalized Charging Stations']

for i, (var, label) in enumerate(zip(variables, labels)):
    axs[i].plot(years, var, 'o', label='Normalized Data')
    axs[i].plot(years, solution[:, i], label='Model')
    axs[i].set_xlabel('Year')
    axs[i].set_ylabel(label)
    axs[i].legend()

plt.tight_layout()
plt.show()

# Calculate and print validation metrics
# Calculate and print validation metrics
r_squared = []
rmse = []
mape = []
mae = []

for i, var in enumerate(variables):
    ss_res = np.sum((var - solution[:, i])**2)
    ss_tot = np.sum((var - np.mean(var))**2)
    r2 = 1 - (ss_res / ss_tot)
    rms_error = np.sqrt(np.mean((var - solution[:, i])**2))
    abs_error = np.abs(var - solution[:, i])
    mean_abs_error = np.mean(abs_error)
    
    # Avoid division by zero in MAPE calculation
    with np.errstate(divide='ignore', invalid='ignore'):
        percentage_errors = np.abs((var - solution[:, i]) / var) * 100
        percentage_errors = np.nan_to_num(percentage_errors, nan=0.0, posinf=0.0, neginf=0.0)
        mean_ape = np.mean(percentage_errors)
    
    r_squared.append(r2)
    rmse.append(rms_error)
    mae.append(mean_abs_error)
    mape.append(mean_ape)

print("\nValidation Metrics:")
print("=" * 50)
for label, r2, rms_error, mean_abs_error, mean_ape in zip(labels, r_squared, rmse, mae, mape):
    print(f"\n{label}:")
    print(f"  R-squared: {r2:.4f}")
    print(f"  RMSE: {rms_error:.6f}")
    print(f"  MAE: {mean_abs_error:.6f}")
    print(f"  MAPE: {mean_ape:.2f}%")
# Imports

# Imports

# Plot settings
plt.style.use('classic')
plt.rcParams.update({
    'font.family': 'serif',
    'font.size': 10,
    'axes.labelsize': 10,
    'figure.facecolor': 'white',
    'axes.facecolor': 'white'
})

# Create figure with extra space
fig = plt.figure(figsize=(14, 12))  # Set appropriate figure size for consistency
gs = GridSpec(4, 2, figure=fig, hspace=0.6, wspace=0.3)  # Adjust grid layout

# Create subplots
axs = []
for i in range(7):
    if i < 6:
        row = i // 2
        col = i % 2
    else:
        row = 3
        col = slice(0, 2)  # Make the last subplot span the entire bottom row
    ax = fig.add_subplot(gs[row, col])
    axs.append(ax)

variables = [V_norm, B_norm, P_norm, F_norm, M_norm, C_norm, S_norm]
labels = ['ICE Vehicles', 'BEVs', 'PHEVs', 'FCEVs', 'VMT', 'CO₂ Emissions', 
          'Charging Stations']
subplot_labels = ['(a)', '(b)', '(c)', '(d)', '(e)', '(f)', '(g)']

# Color scheme
data_color = '#1f77b4'    # Blue dots
model_color = '#ff7f0e'   # Orange line

# Plot data and model
for i, (var, label) in enumerate(zip(variables, labels)):
    axs[i].scatter(years, var, c=data_color, s=30, label='Normalized Data')
    axs[i].plot(years, solution[:, i], c=model_color, linewidth=1.5, label='Model')
    
    # Customize appearance
    axs[i].set_xlabel('Year')
    axs[i].set_ylabel(f'Normalized {label}')
    axs[i].grid(True, linestyle='--', alpha=0.3)
    axs[i].spines['top'].set_visible(False)
    axs[i].spines['right'].set_visible(False)
    
    # Set x-axis ticks and labels
    years_list = list(range(2010, 2024))
    axs[i].set_xticks(years_list)
    axs[i].set_xticklabels(years_list, rotation=45)
    axs[i].set_xlim(2009.5, 2023.5)
    
    # Custom y-axis limits for each plot
    if label == 'ICE Vehicles':
        axs[i].set_ylim(0.80, 1.20)
    elif label == 'BEVs':
        axs[i].set_ylim(-0.5, 4.5)
    elif label == 'PHEVs':
        axs[i].set_ylim(-0.5, 2.5)
    elif label == 'FCEVs':
        axs[i].set_ylim(-0.5, 3.5)
    elif label == 'VMT':
        axs[i].set_ylim(0.80, 1.20)
    elif label == 'CO₂ Emissions':
        axs[i].set_ylim(0.90, 1.10)
    elif label == 'Charging Stations':
        axs[i].set_ylim(-0.5, 3.0)
    
    # Ensure enough y-axis ticks
    axs[i].yaxis.set_major_locator(plt.MaxNLocator(8))
    
    # Add padding to tick labels
    axs[i].tick_params(axis='both', pad=8)

    # Make grid lighter and thinner
    axs[i].grid(True, linestyle='--', alpha=0.2, linewidth=0.5)
    
    # Add subplot labels
    axs[i].text(-0.1, 1.02, subplot_labels[i], transform=axs[i].transAxes, 
            fontsize=12, fontweight='bold')

# Adjust layout for all subplots to be the same size and properly aligned
gs.tight_layout(fig, rect=[0, 0, 0.9, 1])  # Adjust figure to ensure legend doesn't overlap

# Add a legend below the plots, centered horizontally
handles, labels = axs[0].get_legend_handles_labels()
fig.legend(handles, labels, loc='lower center', fontsize=10, frameon=False, bbox_to_anchor=(0.5, -0.05), ncol=2)

# Save figure with extra padding
plt.savefig('model_validation.jpg', dpi=300, bbox_inches='tight',
            facecolor='white', edgecolor='none', pad_inches=0.2)
plt.show()




# Calculate AIC and BIC
n = len(V_norm) * 7
k = len(optimized_params)
sse = np.sum(residual(optimized_params)**2)
aic = 2 * k + n * np.log(sse / n)
bic = np.log(n) * k + n * np.log(sse / n)

print(f"\nAIC: {aic:.4f}")
print(f"BIC: {bic:.4f}")

# Print interpretation of normalized values
print("\nInterpretation of normalized values:")
print("1.0 represents the mean value for each variable over the data period.")
print(f"Mean ICE Vehicles: {V_mean:.0f}")
print(f"Mean BEVs: {B_mean:.0f}")
print(f"Mean PHEVs: {P_mean:.0f}")
print(f"Mean FCEVs: {F_mean:.0f}")
print(f"Mean VMT: {M_mean:.0f} miles/year")
print(f"Mean CO2 Emissions: {C_mean:.0f} metric tons/year")
print(f"Mean Charging Stations: {S_mean:.0f}")

# Calculate and print EV adoption percentage using raw data
total_vehicles = V_data + B_data + P_data + F_data
EV_percentage = (B_data + P_data + F_data) / total_vehicles * 100
print("\nEV adoption percentage:")
print(f"Initial (2010): {EV_percentage[0]:.2f}%")
print(f"Final ({years[-1]}): {EV_percentage[-1]:.2f}%")
 
# Calculate and print projected EV adoption percentage
projected_V = solution[:, 0] * V_mean
projected_B = solution[:, 1] * B_mean
projected_P = solution[:, 2] * P_mean
projected_F = solution[:, 3] * F_mean
projected_total_vehicles = projected_V + projected_B + projected_P + projected_F
projected_EV_percentage = (projected_B + projected_P + projected_F) / projected_total_vehicles * 100
print("\nProjected EV adoption percentage:")
print(f"Initial (2010): {projected_EV_percentage[0]:.2f}%")
print(f"Final ({years[-1]}): {projected_EV_percentage[-1]:.2f}%")

# Print actual and estimated charging stations
print("\nCharging Stations:")
print(f"Initial (2010): Actual: {S_data[0]:.2f}, Estimated: {solution[0, 6] * S_mean:.2f}")
print(f"Final (2023): Actual: {S_data[-1]:.2f}, Estimated: {solution[-1, 6] * S_mean:.2f}")

# Calculate and print CAGR for charging stations
years_diff = years[-1] - years[0]
actual_cagr = (S_data[-1] / S_data[0]) ** (1 / years_diff) - 1
estimated_cagr = (solution[-1, 6] / solution[0, 6]) ** (1 / years_diff) - 1
print(f"\nCompound Annual Growth Rate (CAGR) of charging stations:")
print(f"Actual: {actual_cagr:.2%}")
print(f"Estimated: {estimated_cagr:.2%}")

# Calculate and print total growth for charging stations
actual_total_growth = (S_data[-1] - S_data[0]) / S_data[0]
estimated_total_growth = (solution[-1, 6] - solution[0, 6]) / solution[0, 6]
print(f"\nTotal growth of charging stations from {years[0]} to {years[-1]}:")
print(f"Actual: {actual_total_growth:.2f}x increase ({actual_total_growth*100:.2f}%)")
print(f"Estimated: {estimated_total_growth:.2f}x increase ({estimated_total_growth*100:.2f}%)")

# Calculate and print average annual number of new charging stations
actual_annual_new = (S_data[-1] - S_data[0]) / years_diff
estimated_annual_new = (solution[-1, 6] * S_mean - solution[0, 6] * S_mean) / years_diff
print(f"\nAverage annual number of new charging stations:")
print(f"Actual: {actual_annual_new:.0f}")
print(f"Estimated: {estimated_annual_new:.0f}")