import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp

class BEVAnalysis:
    def __init__(self):
        # Model parameters
        self.params = {
            'r1': 0.05168618830477891,
            'K1': 18.249120552226596,
            'alpha1': 0.000439984626820028,
            'alpha2': 18.203716832193724,
            'alpha3': 7.637298746066146,
            'r2': 0.618,
            'beta1': 0.008630481176530695,
            'gamma1': 0.28377782685370234,
            'r3': 0.4977205757342527,
            'beta2': 3.167966073633332e-05,
            'gamma2': 0.6673314902149782,
            'r4': 0.5887095281051045,
            'beta3': 2.1983443421482386e-05,
            'gamma3': 0.4758914870452181,
            'phi1': 12.605596145217056,
            'phi2': 0.288810618291974,
            'phi3': 0.09182794376396546,
            'phi4': 0.04697673651638769, 
            'eta': 13.279476743655328,
            'psi1': 0.9498918325322229,
            'psi2': 0.9967261435403867,
            'psi3': 1.6041671050490263,
            'psi4': 0.01759812636076682,
            'delta': 0.9384557200652857,
            'epsilon': 0.006353691336850258,
            'zeta': 0.08195297046883737,
            'k_C': 1.9842416005558203,
            'k_V': 0.0078967652396,
            'k_A': 0.00022996575708375,
            'k_D': 0.0595049804633432,
            'lambda_C': 12.503328097970362,
            'lambda_V': 0.06711238756229986,
            'lambda_A': 0.027100037342708213,
            'lambda_D': 0.035885574797121296,
            'lambda_O': 2.1759119997366057,
            'kappa': 0.378394290697231,
            'lambda_S': 0.009714472603102214,
            'omega': 0.021594560008974,
            'tau': 0.03251495646929492,
            'cvrp_end_year': 2023,
            'start_year': 2010  # Used for historical calibration
        }
        self.load_data()

    def load_data(self):
        """Load and normalize data"""
        # Load from ZEVdata.xlsx
        data = pd.read_excel('C:/Users/as3889/Desktop/ZEVdata.xlsx')
            
        self.years = data['Year'].values
        self.V_ICE_data = data['V'].values
        self.V_BEV_data = data['BEV'].values
        self.M_data = data['M'].values
        self.C_data = data['C'].values
        self.S_data = data['S'].values

        # Normalize data
        self.V_ICE_mean = np.mean(self.V_ICE_data)
        self.V_BEV_mean = np.mean(self.V_BEV_data)
        self.M_mean = np.mean(self.M_data)
        self.C_mean = np.mean(self.C_data)
        self.S_mean = np.mean(self.S_data)

        self.V_ICE_norm = self.V_ICE_data / self.V_ICE_mean
        self.V_BEV_norm = self.V_BEV_data / self.V_BEV_mean
        self.M_norm = self.M_data / self.M_mean
        self.C_norm = self.C_data / self.C_mean
        self.S_norm = self.S_data / self.S_mean

    def system(self, t, X, params):
        """System of differential equations for BEV adoption"""
        V, B, M, C, S = X
        
        # Calculate current year from time t
        current_year = params['start_year'] + t
        
        total_vehicles = V + B
        ev_fraction = B / total_vehicles if total_vehicles > 0 else 0

        # Determine which incentives are active based on current year
        active_incentives = 0
        
        # Only include CVRP (k_C) if the current year is at or before the CVRP end year
        if current_year <= params['cvrp_end_year']:
            active_incentives += params['k_C']
        
        # Other incentives continue through the entire simulation
        active_incentives += params['k_V'] + params['k_D'] + params['k_A']

        dV_dt = params['r1'] * V * (1 - total_vehicles/params['K1']) * \
                (1 - params['omega'] * ev_fraction) - params['tau'] * V * ev_fraction - \
                params['epsilon'] * V
        dB_dt = params['r2'] * B + params['beta1'] * active_incentives + \
                params['alpha1'] * params['tau'] * V * ev_fraction - params['gamma1'] * B
        dM_dt = params['phi1'] * V + params['phi2'] * B - params['eta'] * M
        dC_dt = (params['psi1'] * V + params['psi2'] * B) * M / total_vehicles - \
                params['delta'] * C + params['zeta'] * (V / total_vehicles) ** 2
        dS_dt = params['kappa'] * B / total_vehicles - params['lambda_S'] * S

        return [dV_dt, dB_dt, dM_dt, dC_dt, dS_dt]

    def calculate_historical_rmse(self):
        """Calculate RMSE using all historical data"""
        # Initial conditions from 2010
        X0_2010 = [
            self.V_ICE_data[0]/self.V_ICE_mean,
            self.V_BEV_data[0]/self.V_BEV_mean,
            self.M_data[0]/self.M_mean,
            self.C_data[0]/self.C_mean,
            self.S_data[0]/self.S_mean
        ]
        
        # Solve for entire historical period
        years_span = len(self.years)
        t_eval = np.linspace(0, years_span-1, years_span)
        solution = solve_ivp(
            self.system,
            (0, years_span-1),
            X0_2010,
            args=(self.params,),
            t_eval=t_eval,
            method='RK45'
        )
        
        # Get predictions and calculate metrics
        predicted_bev = solution.y[1] * self.V_BEV_mean
        rmse = np.sqrt(np.mean((self.V_BEV_data - predicted_bev)**2))
        rmse_percentage = rmse / np.mean(self.V_BEV_data)
        mae = np.mean(np.abs(self.V_BEV_data - predicted_bev))
        mape = np.mean(np.abs((self.V_BEV_data - predicted_bev) / self.V_BEV_data)) * 100
        
        return {
            'rmse_absolute': rmse,
            'rmse_percentage': rmse_percentage,
            'mae': mae,
            'mape': mape,
            'years': self.years,
            'actual': self.V_BEV_data,
            'predicted': predicted_bev
        }

    def run_scenario_from_2023_with_error(self, growth_ratio, incentive_ratio, rmse, total_budget=5e9, years=4, random_seed=42, n_simulations=10000):
        """Run scenario with Monte Carlo simulation starting from 2023 data
        
        Args:
            random_seed: Fixed seed for reproducibility (required for scientific publication)
            n_simulations: Number of Monte Carlo simulations (10000 recommended for Nature journals)
        """
        # Set random seed for reproducible results
        np.random.seed(random_seed)
        # First, simulate up to 2023 to get the state at that point
        base_params = self.params.copy()
        
        # Initial conditions from 2010
        X0_2010 = [
            self.V_ICE_data[0]/self.V_ICE_mean,
            self.V_BEV_data[0]/self.V_BEV_mean,
            self.M_data[0]/self.M_mean,
            self.C_data[0]/self.C_mean,
            self.S_data[0]/self.S_mean
        ]
        
        # Simulate from 2010 to 2023 (13 years)
        historical_years = 13  # 2010 to 2023
        t_eval_hist = np.linspace(0, historical_years, historical_years*12+1)
        
        historical_solution = solve_ivp(
            self.system,
            (0, historical_years),
            X0_2010,
            args=(base_params,),
            t_eval=t_eval_hist,
            method='RK45'
        )
        
        # Get the final state from 2023 to use as initial state for projections
        X0_2023 = [historical_solution.y[i][-1] for i in range(5)]
        
        # Create parameters for future projection
        scenario_params = self.params.copy()
        
        growth_scaling = 1 + (growth_ratio * total_budget/years/1e9) * 0.30
        incentive_scaling = 1 + (incentive_ratio * total_budget/years/1e9) * 0.32
        
        # Modify parameters for scenario
        scenario_params['r2'] *= growth_scaling
        scenario_params['k_C'] *= incentive_scaling
        scenario_params['k_V'] *= incentive_scaling
        scenario_params['k_A'] *= incentive_scaling
        scenario_params['k_D'] *= incentive_scaling
        scenario_params['beta1'] *= incentive_scaling
        
        # Set the start year to 2023 for the projection period
        scenario_params['start_year'] = 2023
        
        # Future simulation (2023 to 2027) - 4 years
        future_years = 4  # 2023 to 2027
        t_eval_future = np.linspace(0, future_years, future_years*12+1)
        
        future_solution = solve_ivp(
            self.system,
            (0, future_years),
            X0_2023,
            args=(scenario_params,),
            t_eval=t_eval_future,
            method='RK45'
        )
        
        # Process results
        historical_years_array = np.array([2010 + t for t in historical_solution.t])
        future_years_array = np.array([2023 + t for t in future_solution.t])
        
        historical_bev = historical_solution.y[1] * self.V_BEV_mean
        future_bev = future_solution.y[1] * self.V_BEV_mean
        
        # Generate error simulations for future period only
        simulations = np.zeros((len(future_years_array), n_simulations))
        for i in range(n_simulations):
            errors = np.random.normal(0, rmse, size=len(future_years_array))
            simulations[:, i] = future_bev * (1 + errors)
        
        # Calculate confidence intervals for future period
        lower_bound = np.percentile(simulations, 5, axis=1)
        upper_bound = np.percentile(simulations, 95, axis=1)
        mean_prediction = np.mean(simulations, axis=1)
        
        return {
            'historical_years': historical_years_array,
            'historical_bev': historical_bev,
            'future_years': future_years_array,
            'future_mean': mean_prediction,
            'future_lower': lower_bound,
            'future_upper': upper_bound,
            'future_simulations': simulations
        }

    def plot_historical_fit(self, rmse_results):
        """Plot historical model fit"""
        plt.figure(figsize=(12, 6))
        
        # Plot actual values
        plt.plot(rmse_results['years'], 
                rmse_results['actual']/1e6, 
                'bo-', 
                label='Actual', 
                linewidth=2)
        
        # Plot predicted values
        plt.plot(rmse_results['years'], 
                rmse_results['predicted']/1e6, 
                'r--', 
                label='Predicted', 
                linewidth=2)
        
        plt.title('Model Validation (2010-2023)', fontsize=14, pad=20)
        plt.xlabel('Year', fontsize=12)
        plt.ylabel('BEV Vehicles (Millions)', fontsize=12)
        plt.grid(True, linestyle='--', alpha=0.7)
        plt.legend(fontsize=12)
        
        # Rotate x-axis labels for better readability
        plt.xticks(rotation=45)
        
        # Adjust layout to prevent label cutoff
        plt.tight_layout()
        plt.show()

    def plot_scenarios(self, scenario_results, rmse_percentage):
        """Plot scenario comparison"""
        plt.figure(figsize=(14, 8))
        
        colors = {'Growth Focus': 'blue', 'Incentive Focus': 'green'}
        
        for name, results in scenario_results.items():
            color = colors.get(name, 'gray')
            
            # Plot historical period
            plt.plot(results['historical_years'],
                    results['historical_bev']/1e6,
                    linestyle=':',
                    color=color,
                    label=f"{name} (Historical)",
                    alpha=0.7)
            
            # Plot future predictions
            plt.plot(results['future_years'],
                    results['future_mean']/1e6,
                    linestyle='-',
                    color=color,
                    label=f"{name} (Projected)",
                    linewidth=2)
            
            # Add confidence intervals
            plt.fill_between(results['future_years'],
                           results['future_lower']/1e6,
                           results['future_upper']/1e6,
                           color=color,
                           alpha=0.2)
        
        # Add vertical line for projection start
        proj_start_year = 2023
        plt.axvline(x=proj_start_year, color='gray', linestyle='--', alpha=0.5)
        plt.text(proj_start_year + 0.1, plt.ylim()[1]*0.95, 'Projection Start (2023)', 
                rotation=90, verticalalignment='top')
        
        plt.title(f'BEV Adoption Scenarios with Historical RMSE ({rmse_percentage*100:.1f}%)',
                 fontsize=16, pad=20)
        plt.xlabel('Year', fontsize=14)
        plt.ylabel('BEV Vehicles (Millions)', fontsize=14)
        plt.grid(True, linestyle='--', alpha=0.7)
        plt.legend(fontsize=12, bbox_to_anchor=(1.05, 1), loc='upper left')
        
        # Rotate x-axis labels for better readability
        plt.xticks(rotation=45)
        
        # Adjust layout to prevent label cutoff
        plt.tight_layout()
        plt.show()

    def plot_monte_carlo(self, scenario_results, scenario_name):
        """Plot Monte Carlo distribution analysis"""
        result = scenario_results[scenario_name]
        
        plt.figure(figsize=(12, 6))
        plt.hist(
            result['future_simulations'][-1]/1e6,
            bins=50,
            density=True,
            alpha=0.7,
            color='skyblue',
            edgecolor='black'
        )
        plt.axvline(
            result['future_mean'][-1]/1e6,
            color='red',
            linestyle='--',
            label='Mean'
        )
        plt.axvline(
            result['future_lower'][-1]/1e6,
            color='green',
            linestyle=':',
            label='90% CI Lower'
        )
        plt.axvline(
            result['future_upper'][-1]/1e6,
            color='green',
            linestyle=':',
            label='90% CI Upper'
        )
        plt.title(f"Distribution of 2027 BEV Adoption - {scenario_name}")
        plt.xlabel("BEV Vehicles (Millions)")
        plt.ylabel("Density")
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.show()

def main():
    # Initialize analysis
    analysis = BEVAnalysis()
    
    # Calculate historical RMSE
    rmse_results = analysis.calculate_historical_rmse()
    print("\nHistorical Model Performance:")
    print(f"RMSE (%): {rmse_results['rmse_percentage']*100:.2f}%")
    print(f"MAPE: {rmse_results['mape']:.2f}%")
    print(f"MAE: {rmse_results['mae']/1e6:.2f}M vehicles")

    # Plot historical fit
    print("\nPlotting historical model fit...")
    analysis.plot_historical_fit(rmse_results)

    # Define scenarios
    scenarios = {
        "Growth Focus": (0.7, 0.3),
        "Incentive Focus": (0.3, 0.7)
    }

    print("\n===== Monte Carlo Simulation Starting from 2023 =====")
    # Run scenarios starting from 2023
    print("\nRunning scenarios (starting from 2023)...")
    scenario_results = {}
    for name, (growth_ratio, incentive_ratio) in scenarios.items():
        print(f"\nProcessing {name} scenario...")
        results = analysis.run_scenario_from_2023_with_error(
            growth_ratio,
            incentive_ratio,
            rmse_results['rmse_percentage'],
            total_budget=5e9,
            years=4,
            random_seed=42,  # Fixed seed for reproducibility
            n_simulations=10000  # Higher precision for publication
        )
        scenario_results[name] = results

    # Plot scenarios
    print("\nPlotting scenario comparisons...")
    analysis.plot_scenarios(scenario_results, rmse_results['rmse_percentage'])

    # Plot Monte Carlo results for each scenario
    print("\nGenerating Monte Carlo distribution plots...")
    for scenario_name in scenarios.keys():
        print(f"\nPlotting Monte Carlo distribution for {scenario_name}...")
        analysis.plot_monte_carlo(scenario_results, scenario_name)

    # Print final results
    print("\nFinal Results Summary:")
    for name in scenario_results:
        result = scenario_results[name]
        final_mean = result['future_mean'][-1]/1e6
        final_lower = result['future_lower'][-1]/1e6
        final_upper = result['future_upper'][-1]/1e6
        
        print(f"\n{name}:")
        print(f"  Projected 2027 BEV Fleet (Mean): {final_mean:.2f}M vehicles")
        print(f"  90% Confidence Interval: [{final_lower:.2f}M, {final_upper:.2f}M]")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"Error in analysis: {str(e)}")
        import traceback
        traceback.print_exc()
        print("Please ensure all data files are available and properly formatted.")